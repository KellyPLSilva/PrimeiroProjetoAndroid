package com.example.uttpaycoin;

import android.content.res.Configuration;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

public class Usuario extends AppCompatActivity {

    public void cadastrarUsuario(final Usuario usuario){
   /* autenticacao = //ConfigurationBancoSqlite// .getFirebaseAutenticacao();
            autenticacao.creatUserWithEmailAndPassword(
                    usuario.getEmail(),
                    usuario.getSenha()
            ).addOnCompleteListener(this,new MediaPlayer.OnCompletionListener()<Result>(){

        }
    }
}
