package com.example.uttpaycoin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;

public class E_TelaCadastro extends AppCompatActivity {

    Button BotaoLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.e_telacadastrar);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        BotaoLogin = findViewById(R.id.btn_Entrar_TelaLogin);

        BotaoLogin.setOnClickListener(view -> {
            Intent it = new Intent(getApplicationContext(), G_TelaSaldo.class);
            startActivity(it);
        });
    }
}