package com.example.uttpaycoin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class B_TelaIntroducao extends AppCompatActivity {

    Button BotaoIntro1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.b_introducao);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        BotaoIntro1 = findViewById(R.id.btn_Proximo_Introducao);

        BotaoIntro1.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Intent menino = new Intent(getApplicationContext(), C_Introducao.class);
                startActivity(menino);

            }
        });

    }
}