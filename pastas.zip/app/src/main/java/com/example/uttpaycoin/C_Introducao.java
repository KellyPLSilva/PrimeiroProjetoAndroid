package com.example.uttpaycoin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class C_Introducao extends AppCompatActivity {

    Button BotaoIntro2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_introducao);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        BotaoIntro2 = findViewById(R.id.btn_Proximo_Intro3);

        BotaoIntro2.setOnClickListener (new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent menina = new Intent(getApplicationContext(),D_TelaEntrada.class);
                startActivity(menina);
            }
        });

        }
    }



