package com.example.uttpaycoin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class A_MainActivity extends AppCompatActivity {

    Button BotaoIntro;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_introducao);
        //oculta barra superior e o tíluo do projeto//
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);


        BotaoIntro = findViewById(R.id.btn_Proximo_Introducao);

        BotaoIntro.setOnClickListener(view -> {
            Intent it = new Intent(getApplicationContext(), C_Introducao.class);
            startActivity(it);

        });
    }

}








